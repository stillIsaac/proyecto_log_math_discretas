#libraries for clearing the console
from os import system, name
from time import sleep

#function for clearing the console
def clear():
   # for windows
   if name == 'nt':
      _ = system('cls')

   # for mac and linux
   else:
     _ = system('clear')

#THIS ARE ALL THE ARRAYS THAT I AM GOING TO BE USING

#If the original array,the one with the asterisk, has only one box of the array with a number, then this is going to be True, if not, is False
arr_state = False

#This is for giving the size of the array
rows, cols = (4, 4)
arr = [[0 for i in range(cols)] for j in range(rows)]

#This is the array that is going to be used to verify if what the username is saying is correct
arr = [ [70, 78, 93, 60], [82, 96, 70, 94], [96, 91,   82, 78], [ 93, 91, 60, 94] ] 

# This is the array that is going to be shown in the first time to the username, it is going to change while the username is playing 
arr1 = [[0 for i in range(cols)] for j in       range(rows)]
  
arr1 = [ ["**", "**", "**", "**"], ["**", "**", "**", "**"], ["**", "**", "**", "**"], [ "**", "**", "**", "**"] ]


#this is for printing the array
def print_arr(arr):
  for row in arr:   
    print(row)

def asterisk_num(arr, arr1, key_opt1, key_opt2):  
    print("This is the spot you selected:")
    for i in range(4):
      for j in range(4):
          if int(key_opt1) == i and int(key_opt2) == j:
              arr1[i][j] = arr[i][j]
              print_arr(arr1)
              sleep(5)
              clear()
              arr1[i][j] = "**"


def jugada1():
#Jugada 1
  print_arr(arr1)
  print("Write the number of the row of your first option (remember that it is starts with 0 not with 1):")
  key_opt1 = input()
  print("Write the number of the column of your first option:")
  key_opt2 = input()
  clear()
  asterisk_num(arr, arr1, key_opt1, key_opt2)
  print_arr(arr1)
#Jugada 2
  print("Write the number of the row of your second option (remember that it is starts with 0 not with 1):")
  key_opt3 = input()
  print("Write the number of the column of your second option:")
  key_opt4 = input()
  clear()
  asterisk_num(arr, arr1, key_opt3, key_opt4)
  if arr[int(key_opt1)][int(key_opt2)] == arr[int(key_opt3)][int(key_opt4)]:
    print("Correct")
    arr1[int(key_opt1)][int(key_opt2)] = arr[int(key_opt1)][int(key_opt2)]
    arr1[int(key_opt3)][int(key_opt4)] = arr[int(key_opt3)][int(key_opt4)]

    

#def game_on (yes_no):
  #if(yes_no == 'Y'):
    #while(3<5):
      
#Anouncement of the game
print("**JUEGO DE PAREJAS Y CONCÉNTRESE**")
print("By Juan José R e Isaac J")
sleep(3)
clear()



print("Do you want to play [Y/n]")
yes_no = input()

if(yes_no == 'n'):
  clear()
  print("Nos vemos en otra ocasión")


elif(yes_no == 'Y'):
  i = 1
  print("Let's start! You have 11 attempts to complete the game")
  while i < 12:
    i += 1
    jugada1()
  print("You have exceeded the amount of posible attempts")  



else:
  clear()
  print("Error, por favor ingresa la tecla Y o n y luego pon enter.")